﻿import mysql.connector
import config

def get_db_connection():
    return mysql.connector.connect(
        host=config.DB_CONFIG['host'],
        user=config.DB_CONFIG['user'],
        password=config.DB_CONFIG['password'],
        database=config.DB_CONFIG['database']
    )
