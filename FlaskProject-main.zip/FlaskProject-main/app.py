﻿from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_mail import Mail, Message
from itsdangerous import URLSafeTimedSerializer
import mysql.connector
from werkzeug.security import generate_password_hash, check_password_hash
import config

app = Flask(__name__)
app.secret_key = config.SECRET_KEY

# Email setup
app.config.update(
    MAIL_SERVER='smtp.gmail.com',
    MAIL_PORT=587,
    MAIL_USE_TLS=True,
    MAIL_USERNAME=config.EMAIL_CONFIG['EMAIL_USER'],
    MAIL_PASSWORD=config.EMAIL_CONFIG['EMAIL_PASS']
)
mail = Mail(app)
s = URLSafeTimedSerializer(app.secret_key)

from database import get_db_connection
from models import *



@app.route('/')
def index():
    games = get_games()
    owned_game_ids = []

    if 'user' in session:
        user = get_user_by_username(session['user'])
        if user:
            owned_games = get_owned_games(user['user_id'])
            owned_game_ids = [game['game_id'] for game in owned_games]

    return render_template('index.html', games=games, owned_game_ids=owned_game_ids)


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        confirm = request.form['confirm']
        if password != confirm:
            flash('Passwords do not match', 'danger')
            return redirect(url_for('register'))

        hashed_pw = generate_password_hash(password)
        if create_user(username, email, hashed_pw):
            flash('Account created successfully. Please log in.', 'success')
            return redirect(url_for('login'))
        else:
            flash('User already exists', 'danger')
    return render_template('register.html')

from flask import Flask, render_template, request, redirect, url_for, flash, session
# ... your existing imports

@app.route('/add_to_cart/<int:game_id>', methods=['POST'])
def add_to_cart(game_id):
    if 'user' not in session:
        flash('Please login to add games to your cart.', 'warning')
        return redirect(url_for('login'))

    cart = session.get('cart', [])
    if game_id not in cart:
        cart.append(game_id)
        session['cart'] = cart
        flash('Game added to cart!', 'success')
    else:
        flash('Game already in cart.', 'info')
    return redirect(request.referrer or url_for('index'))

@app.route('/cart')
def view_cart():
    if 'user' not in session:
        flash('Please login to view your cart.', 'warning')
        return redirect(url_for('login'))

    cart = session.get('cart', [])
    games_in_cart = []
    for game_id in cart:
        game = get_game_by_id(game_id)
        if game:
            games_in_cart.append(game)

    return render_template('cart.html', games=games_in_cart)

@app.route('/checkout', methods=['POST'])
def checkout():
    if 'user' not in session:
        flash('Please login to checkout.', 'warning')
        return redirect(url_for('login'))

    cart = session.get('cart', [])
    if not cart:
        flash('Your cart is empty.', 'info')
        return redirect(url_for('view_cart'))

    user = get_user_by_username(session['user'])
    if not user:
        flash('User not found.', 'danger')
        return redirect(url_for('login'))

    for game_id in cart:
        add_game_to_user(user['user_id'], game_id)  # function to insert into user_owned_games

    session.pop('cart')  # clear cart after purchase
    flash('Purchase complete! Games added to your library.', 'success')
    return redirect(url_for('index'))


from models import get_owned_games

@app.route('/library')
def library():
    if 'user' not in session:
        flash('Please login to view your library.', 'warning')
        return redirect(url_for('login'))

    user = get_user_by_username(session['user'])  # You should already have this function
    if not user:
        flash('User not found.', 'danger')
        return redirect(url_for('login'))

    owned_games = get_owned_games(user['user_id'])
    return render_template('library.html', games=owned_games)



@app.route('/confirm/<token>')
def confirm_email(token):
    try:
        email = s.loads(token, salt='email-confirm', max_age=3600)
        confirm_user_email(email)
        flash('Email confirmed! You can log in now.', 'success')
    except:
        flash('The confirmation link is invalid or has expired.', 'danger')
    return redirect(url_for('login'))

@app.route('/game/<int:game_id>')
def game_detail(game_id):
    game = get_game_by_id(game_id)
    if not game:
        flash('Game not found.', 'danger')
        return redirect(url_for('index'))
    return render_template('game_detail.html', game=game)

@app.route('/buy/<int:game_id>', methods=['POST'])
def buy_game(game_id):
    if 'user' not in session:
        flash('Please log in to buy games.', 'warning')
        return redirect(url_for('login'))

    user = get_user_by_username(session['user'])
    if user and add_game_to_user(user['user_id'], game_id):
        flash('Game purchased successfully!', 'success')
    else:
        flash('You already own this game or an error occurred.', 'danger')

    return redirect(url_for('game_detail', game_id=game_id))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = get_user_by_email(email)
        if user and check_password_hash(user['password_hash'], password):
            session['user'] = user['username']
            return redirect(url_for('index'))
        flash('Invalid credentials', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    flash('Logged out.', 'info')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
