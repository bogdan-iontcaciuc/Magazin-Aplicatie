﻿SECRET_KEY = 'randomsadasfsafjisajoifhasf234'

DB_CONFIG = {
    'host': 'localhost',
    'user': 'appUser',
    'password': 'StandardUser',
    'database': 'shftclient'
}

EMAIL_CONFIG = {
    'EMAIL_USER': 'rokarambit@gmail.com',
    'EMAIL_PASS': 'admin123'  # App password, not your actual Gmail password
}
