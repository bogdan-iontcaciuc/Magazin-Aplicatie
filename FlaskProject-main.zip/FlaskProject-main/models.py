﻿from database import get_db_connection

def create_user(username, email, password_hash):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT user_id FROM users WHERE email = %s OR username = %s", (email, username))
        if cursor.fetchone():
            return False

        cursor.execute(
            "INSERT INTO users (username, email, password_hash) VALUES (%s, %s, %s)",
            (username, email, password_hash)
        )
        conn.commit()
        return True
    except Exception as e:
        print("Error creating user:", e)
        return False
    finally:
        cursor.close()
        conn.close()
def confirm_user_email(email):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET confirmed = TRUE WHERE email = %s", (email,))
    conn.commit()
    cursor.close()
    conn.close()
def get_game_by_id(game_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM games WHERE game_id = %s", (game_id,))
    game = cursor.fetchone()
    cursor.close()
    conn.close()
    return game

def add_game_to_user(user_id, game_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT IGNORE INTO user_owned_games (user_id, game_id) VALUES (%s, %s)",
            (user_id, game_id)
        )
        conn.commit()
    except Exception as e:
        print(f"Error adding game to user: {e}")
    finally:
        cursor.close()
        conn.close()
def get_owned_games(user_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT g.*
        FROM games g
        JOIN user_owned_games ug ON g.game_id = ug.game_id
        WHERE ug.user_id = %s
    """, (user_id,))
    games = cursor.fetchall()
    cursor.close()
    conn.close()
    return games

def get_user_by_username(username):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
    user = cursor.fetchone()
    cursor.close()
    conn.close()
    return user


def get_user_by_email(email):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
    user = cursor.fetchone()
    cursor.close()
    conn.close()
    return user

def get_games():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM games")
    games = cursor.fetchall()
    cursor.close()
    conn.close()
    return games
